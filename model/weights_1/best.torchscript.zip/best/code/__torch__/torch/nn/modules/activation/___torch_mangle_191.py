class SiLU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward1(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward2(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward3(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward4(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward5(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward6(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward7(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward8(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward9(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward10(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward11(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward12(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward13(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward14(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward15(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward16(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward17(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward18(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward19(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward20(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward21(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward22(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward23(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward24(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward25(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward26(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward27(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward28(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward29(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward30(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward31(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward32(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward33(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward34(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward35(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward36(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward37(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward38(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward39(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward40(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward41(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward42(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward43(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward44(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward45(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward46(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward47(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward48(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward49(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward50(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward51(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward52(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward53(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward54(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward55(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward56(self: __torch__.torch.nn.modules.activation.___torch_mangle_191.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
